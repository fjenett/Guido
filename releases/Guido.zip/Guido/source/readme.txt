Please note that although this is the full source code you should rather download the whole package (incl build script) from Github at:

https://github.com/fjenett/Guido

