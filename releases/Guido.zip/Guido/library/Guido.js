if(!Interactive) {
  var Interactive = function() {
    var f, j, k, l, m, i = function(c, a) {
      for(var b in a) {
        if(a[b] in c && "function" === typeof c[a[b]]) {
          return c[a[b]]
        }
      }
      return function() {
      }
    }, h = function(c) {
      this.target = c.target;
      if(document.defaultView && document.defaultView.getComputedStyle) {
        var a = document.defaultView.getComputedStyle(this.target, null);
        j = parseInt(a.paddingLeft, 10) || 0;
        k = parseInt(a.paddingTop, 10) || 0;
        l = parseInt(a.borderLeftWidth, 10) || 0;
        m = parseInt(a.borderTopWidth, 10) || 0
      }
      this.listeners = [];
      if(c.papplet && "draw" in c.papplet) {
        var b = this, g = c.papplet, d = c.papplet.draw;
        c.papplet.draw = function() {
          b.preDraw(g);
          d.apply(g);
          b.postDraw(g)
        }
      }
      var c = "mousemove mousedown mouseup click dblclick mouseover mouseout mouseenter mouseleave mousewheel DOMMouseScroll".split(" "), a = {mousemove:"mouseMoved", mousedown:"mousePressed", dblclick:"mouseDoubleClicked", mouseup:"mouseReleased", mousewheel:"mouseScrolled", DOMMouseScroll:"mouseScrolled"}, e;
      for(e in c) {
        (function(a, c, b, g) {
          var d = function(b) {
            var d, e;
            d = c;
            var f = 0;
            e = 0;
            if(d.offsetParent) {
              do {
                f += d.offsetLeft, e += d.offsetTop
              }while(d = d.offsetParent)
            }
            d = c;
            do {
              f -= d.scrollLeft || 0, e -= d.scrollTop || 0
            }while(d = d.parentNode);
            f += j;
            e += k;
            f += l;
            e += m;
            f += window.pageXOffset;
            e += window.pageYOffset;
            d = f;
            for(var h in a.listeners) {
              if(a.listeners[h].isActive() && g in a.listeners[h]) {
                if("mouseScrolled" == g) {
                  a.listeners[h][g](b.detail ? -1 * b.detail : b.wheelDelta / 40, b.pageX - d, b.pageY - e)
                }else {
                  a.listeners[h][g](b.pageX - d, b.pageY - e)
                }
              }
            }
          };
          if("addEventListener" in c) {
            c.addEventListener(b, d)
          }else {
            var e = c["on" + b];
            c["on" + b] = function(a) {
              var b = d.apply(a.target, [a]);
              e && e.apply(c, [a]);
              return b
            }
          }
        })(this, this.target, c[e], a[c[e]])
      }
      this.add = function(a) {
        this.listeners.push(a)
      };
      this.remove = function(a) {
        for(var b = 0, c = this.listeners.length;b < c;b++) {
          this.listeners[b].listener == a && this.listeners.splice(b, 1)
        }
      };
      this.preDraw = function() {
      };
      this.postDraw = function(a) {
        if(this.listeners) {
          for(var b in this.listeners) {
            "draw" in this.listeners[b] && this.listeners[b].draw(a)
          }
        }
      }
    };
    h.make = function(c) {
      f = new h({target:c.externals.canvas, papplet:c})
    };
    h.add = function(c) {
      var a = null;
      if(f) {
        if("[object Array]" === Object.prototype.toString.call(c)) {
          for(var a = 0, b = c.length;a < b;a++) {
            f.add(new n(c[a]))
          }
          return null
        }
        a = new n(c);
        f.add(a)
      }
      return a
    };
    h.remove = function(c) {
      if(f) {
        if("[object Array]" === Object.prototype.toString.call(c)) {
          for(var a = 0, b = c.length;a < b;a++) {
            f.remove(c[a])
          }
        }else {
          f.remove(c)
        }
      }
      return null
    };
    h.setActive = function(c, a) {
      if(f) {
        for(var b in f.listeners) {
          var g = f.listeners[b];
          g.listener == c && g.setActive(a)
        }
      }
    };
    h.insideRect = function(c, a, b, g, d, e) {
      return d >= c && d <= c + b && e >= a && e <= a + g
    };
    h.on = function() {
      if(f) {
        var c = f;
        c.eventBindings || (c.eventBindings = []);
        var a, b, g, d;
        if(3 > arguments.length) {
          throw"Interactive.on() ... not enough arguments";
        }
        3 == arguments.length ? (a = null, b = arguments[0], g = arguments[1], d = arguments[2]) : 4 == arguments.length && (a = arguments[0], b = arguments[1], g = arguments[2], d = arguments[3]);
        if(!g) {
          throw"Interactive.on() ... the target is null";
        }
        if(!(d in g) || "function" !== typeof g[d]) {
          throw"Interactive.on() ... that method does not exist";
        }
        var e = c.eventBindings[b];
        e || (e = [], c.eventBindings[b] = e);
        e.push({callback:function() {
          g[d].apply(g, arguments)
        }, source:a})
      }
    };
    h.send = function() {
      if(f) {
        var c = f, a, b, g = [];
        if(1 > arguments.length) {
          throw"Interactive.send() ... not enough arguments";
        }
        if("object" === typeof arguments[0]) {
          a = arguments[0];
          b = arguments[1];
          var d = 2, e = arguments.length
        }else {
          a = null, b = arguments[0], d = 1, e = arguments.length
        }
        for(;d < e;d++) {
          g.push(arguments[d])
        }
        if(c = c.eventBindings[b]) {
          d = 0;
          for(e = c.length;d < e;d++) {
            c[d] && c[d].source === a && c[d].callback.apply(null, g)
          }
        }
      }
    };
    var n = function(c) {
      this.listener = c;
      "isInside" in this.listener || ("x" in this.listener && "y" in this.listener && "width" in this.listener && "height" in this.listener ? this.listener.isInside = function(a, b) {
        return h.insideRect(this.x, this.y, this.width, this.height, a, b)
      } : alert("Interactive: listener must implement\n\tpublic boolean isInside (float mx, float my)\nor must have fields\n\tfloat x, y, width, height;"));
      this.pressed = this.dragged = this.hover = !1;
      this.activated = !0;
      this.lastPressed = this.draggedDistY = this.draggedDistX = this.clickedPositionY = this.clickedPositionX = this.clickedMouseY = this.clickedMouseX = 0;
      this.activated = !0;
      this.debug = !1;
      this.setDebug = function(a) {
        this.debug = a ? true : false
      };
      this.mousePressed = this.mousePressedAt = function(a, b) {
        if(this.activated) {
          if(this.pressed = this.listener.isInside(a, b)) {
            this.clickedPositionX = this.listener.x;
            this.clickedPositionY = this.listener.y;
            this.clickedMouseX = a;
            this.clickedMouseY = b;
            i(["mousePressed", "mousePressedAt"], this.listener)(a, b)
          }
        }
      };
      this.mouseDoubleClicked = this.mouseDoubleClickedAt = function(a, b) {
        this.activated && this.listener.isInside(a, b) && i(["mouseDoubleClicked", "mouseDoubleClickedAt"], this.listener)(a, b)
      };
      this.mouseMoved = this.mouseMovedAt = function(a, b) {
        if(this.activated) {
          if(this.dragged = this.pressed) {
            this.draggedDistX = this.clickedMouseX - a;
            this.draggedDistY = this.clickedMouseY - b;
            i(["mouseDraggedAt", "mouseDraggedFromTo"], this.listener)(a, b, this.clickedPositionX - this.draggedDistX, this.clickedPositionY - this.draggedDistY)
          }else {
            var c = this.listener.isInside(a, b);
            !c && this.hover ? i(["mouseExited", "mouseExitedAt"], this.listener)(a, b) : c && !this.hover ? i(["mouseEntered", "mouseEnteredAt"], this.listener)(a, b) : c && i(["mouseMoved", "mouseMovedAt"], this.listener)(a, b);
            this.hover = c
          }
        }
      };
      this.mouseReleased = this.mouseReleasedAt = function(a, b) {
        if(this.activated) {
          if(this.dragged) {
            this.draggedDistX = this.clickedMouseX - a;
            this.draggedDistY = this.clickedMouseY - b
          }
          this.pressed && i(["mouseReleased", "mouseReleasedAt"], this.listener)(a, b);
          this.pressed = this.dragged = false
        }
      };
      this.mouseScrolled = function(a, b, c) {
        this.activated && this.listener.isInside(b, c) && "mouseScrolled" in this.listener && this.listener.mouseScrolled(a)
      };
      this.setActive = function(a) {
        this.activated = a;
        this.listener && "setActive" in this.listener && this.listener.setActive(a)
      };
      this.isActive = function() {
        return this.listener && "isActive" in this.listener ? this.listener.isActive() : this.activated
      };
      this.draw = function(a) {
        if(this.activated && this.listener && "draw" in this.listener) {
          return this.listener.draw(a)
        }
      }
    };
    return h
  }()
}
;